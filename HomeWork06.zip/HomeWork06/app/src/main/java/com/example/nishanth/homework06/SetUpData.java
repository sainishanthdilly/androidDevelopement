package com.example.nishanth.homework06;

import java.util.ArrayList;

/**
 * Created by nishanth on 2/24/2017.
 */
/*
Sai Nishanth Dilly
Shireen Shaik
Group 04
 */

public interface SetUpData {

    public void setData(ArrayList<ITunesPojo> arrayList);
}
