package com.example.nishanth.homework09;

/**
 * Created by nishanth on 4/20/2017.
 */

interface ButtonClickCallBack {


    public void onButtonClickSetData(int adapterPosition, Object tag);
}
