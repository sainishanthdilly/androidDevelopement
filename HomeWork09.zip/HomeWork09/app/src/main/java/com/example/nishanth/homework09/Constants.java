package com.example.nishanth.homework09;

/**
 * Created by razor on 4/8/15.
 */
public class Constants {
    public static final String API_NOT_CONNECTED = "Google API not connected";
    public static final String SOMETHING_WENT_WRONG = "OOPs!!! Something went wrong...";
    public static String PlacesTag = "Google Places Auto Complete";
}
