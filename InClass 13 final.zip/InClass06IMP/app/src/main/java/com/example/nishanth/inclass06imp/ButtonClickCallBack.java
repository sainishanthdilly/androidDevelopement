package com.example.nishanth.inclass06imp;

/**
 * Created by nishanth on 3/11/2017.
 */

public interface ButtonClickCallBack {


        public void onPlayButtonClick(int p);
        public void onCheckedClickCallBack(int p,String status);



}
