package com.example.nishanth.homework07;

/**
 * Created by nishanth on 3/11/2017.
 */

public interface ButtonClickCallBack {


        public void onPlayButtonClick(int p);



}
