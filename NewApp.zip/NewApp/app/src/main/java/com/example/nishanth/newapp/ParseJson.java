package com.example.nishanth.newapp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by nishanth on 2/6/2017.
 */

public class ParseJson {

    ArrayList<NewsData> parseJsonNews(String s)
    {

        ArrayList<NewsData> al = new ArrayList<NewsData>();

        try {
            JSONObject root = new JSONObject(s);


        JSONArray articles = root.getJSONArray("articles");

          for(int i=0; i< articles.length() ; i++){

              JSONObject ob = articles.getJSONObject(i);
              String a =(String) ob.get("author");
              String t = (String)        ob.get("title");
             String d =(String) ob.get("description");
            String u = (String)      ob.get("url");
            String il= (String)       ob.get("urlToImage");
              String p =(String)      ob.get( "publishedAt");

              al.add(new NewsData(a,t,d,u,il,p));



          }


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return al;


    }
}
