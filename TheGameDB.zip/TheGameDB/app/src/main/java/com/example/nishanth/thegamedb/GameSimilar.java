package com.example.nishanth.thegamedb;

/**
 * Created by nishanth on 2/19/2017.
 */

public class GameSimilar {

    String gameTitle;
    String releaseDate;
    String platform;




    public String getGameTitle() {
        return gameTitle;
    }

    public void setGameTitle(String gameTitle) {
        this.gameTitle = gameTitle;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }
}
